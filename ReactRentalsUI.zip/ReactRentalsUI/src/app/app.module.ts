import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RentService } from './rent/rent.service';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RentComponent } from './rent/rent.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewComponent } from './view/view.component';


@NgModule({
  declarations: [
    AppComponent,
    RentComponent,
    ViewComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
 
  ],
  providers: [RentService],
  bootstrap: [AppComponent]
})
export class AppModule { }

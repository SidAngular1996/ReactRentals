import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common/src/pipes/date_pipe';
import { RentService } from './rent.service';
@Component({
  selector: 'app-rent',
  templateUrl: './rent.component.html',
  styleUrls: ['./rent.component.css'],
})
export class RentComponent implements OnInit {

  errorMessage: string;
  successMessage: string;
  timeArray = ["09:00AM", "11:00AM", "01:00PM", "03:00PM", "05:00PM"];
  rentForm:FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private rentService: RentService) { }
  
  ngOnInit() {
    this.rentForm = this.fb.group({
      /* Include the required validations for the given form controls here */
      employeeName: [],
      employeeId: [],
      startDate: [],
      startTime: [],
      endDate: [],
      vehicleType: []
    })
  }
  
  rentAvehicle() {
    /* Code the method to invoke service and populate message */
  }
}
function validateStartDate(date: FormControl) {
  /* write the custom validator here to validate the rent startDate should not be before today */
}



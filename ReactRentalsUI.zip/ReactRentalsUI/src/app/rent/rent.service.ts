import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { rentedVehicle } from '../shared/rentedVehicle';

@Injectable()
export class RentService {
  constructor() { }

  renter(data: any) : Observable<rentedVehicle> {
    // write the appropriate http method call to rent a vehicle
  }
}

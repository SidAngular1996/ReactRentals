import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { rentedVehicle } from '../shared/rentedVehicle';
import { Employee } from '../shared/Employee';

@Injectable({
  providedIn: 'root'
})
export class ViewService {

  constructor(private http: HttpClient) { }
  
  getBooking(id): Observable<rentedVehicle>{
    /* code the appropriate http request here to fetch the booking details for an employee */ 
  }
}


import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { rentedVehicle } from '../shared/rentedVehicle';
import {ViewService} from './view.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css'],
})
export class ViewComponent implements OnInit {
  errorMessage: string;
  employeeId: string;
  selectedBookings: any;
  constructor(private getViewService: ViewService) { }

  ngOnInit() { }
  
  getBooking(){
    /* write the appropriate service call here to fetch the booking details for a particular employee Id*/ 
  }
}

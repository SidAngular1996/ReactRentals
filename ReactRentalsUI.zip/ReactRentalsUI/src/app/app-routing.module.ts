import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* import the neccessary files here */

const routes: Routes = [
  /* mention the route path's and their corresponding components here */
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

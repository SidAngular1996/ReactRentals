export class rentedVehicle{
    rentId : number;
    employeeName : string;
    startDate : string;
    vehicleType : string;
    endDate : string;
    startTime: string;
    employeeId : number;
    rentAmount : number;
    message:string;
}
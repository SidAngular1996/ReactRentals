export class Employee{
    employeeId:number;
    employeeName:string;
}